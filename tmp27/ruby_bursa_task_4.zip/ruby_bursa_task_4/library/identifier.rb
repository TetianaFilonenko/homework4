module Library
module Identifier



end   # ident
end   # library
