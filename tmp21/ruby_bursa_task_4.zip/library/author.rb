require_relative "commentable.rb"
module Library
	class Author
		include ::Library::Commentable	
		
		attr_accessor :year_of_birth, :year_of_death, :name

		def initialize year_of_birth, year_of_death, name
			@year_of_birth = year_of_birth
			@year_of_death = year_of_death
			@name = name
		end
		
	end
end
