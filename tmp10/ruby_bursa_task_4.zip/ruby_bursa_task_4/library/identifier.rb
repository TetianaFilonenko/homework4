module Library
	module Identifier 

		def self.included(base)
			base.send :extend, Methods
			base.send :class_variable_set, :@@group_identifier, 0
		end

    module Methods

      def group_identifier
      	
        self.class_variable_set(:@@group_identifier, self.class_variable_get(:@@group_identifier) + 1)
 
    end
end

		extend ActiveSupport::Concern

		def ==(x)
			object_id==x.object_id
		end

		def eql?(x)
			object_id==x.object_id
		end

		def identifier



		end

	end
end