module Library
  module Identifier
    @@group_identifier = ''
  end
end