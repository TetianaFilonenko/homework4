module Library
  module Identifier
  	@@group_identifier = 0

  	def identify
  		self.class_variable_get :@@group_identifier
    end
    def object_identifier increment
    	@identifier += increment
    end
    def eql? other
         @identifier.eql other
    end
    def == other
    	@idenitfier == other.identifier
    end
    end
 end