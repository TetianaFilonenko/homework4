require 'active_support/all'
require 'pry'

module Library

end

module Identifier

	@@group_identifier = 0

end
def self.included(base)
      base.send :extend, ClassMethods
      base.send :class_variable_set, :@@group_identifier, 0
    end

    module ClassMethods

      def group_identifier
        self.class_variable_get :@identifier
      end

      def inc_group_or_init 
        self.class_variable_set :@@group_identifier, self.class_variable_get(:@@group_identifier) 
      end
      
    def == other
      @identifier == other.identifier
    end


	  def eql? other
	  	 @identifier == other.identifier
	  end
    end


require_relative 'commentable.rb'
require_relative 'author.rb'
require_relative 'book.rb'
require_relative 'published_book.rb'
require_relative 'reader.rb'
require_relative 'reader_with_book.rb'
require_relative 'manager.rb'
